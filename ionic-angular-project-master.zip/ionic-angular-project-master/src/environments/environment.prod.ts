export const environment = {
	production: true,
	googleMapsAPIKey: '',
	firebaseAPIKey: ''
};
